$(function(){
	plumeLog("进入test1模板自定义js-"+plumeTime());

})