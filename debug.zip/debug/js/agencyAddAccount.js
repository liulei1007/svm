$(function() {
	$("#addAccount").on("click", ".back", function() {
		derict(this,thisUrl,"nochangeurl");
	});
});
