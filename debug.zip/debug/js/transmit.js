
$(function () {
    plumeLog("进入transmit模板自定义js-" + plumeTime());
    clearTimeout(transmit_loop)
    transmit_showLoad();
})

