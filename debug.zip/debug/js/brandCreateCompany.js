$(function() {
    plumeLog("进入brandCreateCompany模板自定义js-"+plumeTime());
    formCtrl();
});
