$(function(){
	plumeLog("进入brandAdd模板自定义js-"+plumeTime());
	$("#brandname").val(session.pram1);
})