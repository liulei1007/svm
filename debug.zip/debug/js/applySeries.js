$(function(){
	plumeLog("进入commondityManagement3模板自定义js-"+plumeTime());
	$('.applyPopup').loadTemp("applyPopup","nochangeurl")
})