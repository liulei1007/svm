$(function(){
	plumeLog("进入table模板自定义js-"+plumeTime());

})